package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type Person struct {
	Surname    string `json:"surname"`
	Name       string `json:"name"`
	Patronymic string `json:"patronymic"`
	Address    string `json:"address"`
}

var peopleData = map[string]Person{
	"1234_567890": {
		Surname:    "Иванов",
		Name:       "Иван",
		Patronymic: "Иванович",
		Address:    "г. Москва, ул. Ленина, д. 5, кв. 1",
	},
	"1234_98765": {
		Surname:    "Петров",
		Name:       "Петр",
		Patronymic: "Петрович",
		Address:    "г. Санкт-Петербург, ул. Пушкина, д. 10, кв. 2",
	},
	"3456_789012": {
		Surname:    "Сидоров",
		Name:       "Сидор",
		Patronymic: "Сидорович",
		Address:    "г. Новосибирск, ул. Советская, д. 15, кв. 3",
	},
	"4567_890123": {
		Surname:    "Кузнецов",
		Name:       "Кузьма",
		Patronymic: "Кузьмич",
		Address:    "г. Екатеринбург, ул. Мира, д. 7, кв. 4",
	},
	"5678_901234": {
		Surname:    "Смирнов",
		Name:       "Семен",
		Patronymic: "Семенович",
		Address:    "г. Казань, ул. Баумана, д. 20, кв. 5",
	},
	"6789_012345": {
		Surname:    "Васильев",
		Name:       "Василий",
		Patronymic: "Васильевич",
		Address:    "г. Омск, ул. Лермонтова, д. 12, кв. 6",
	},
	"7890_123456": {
		Surname:    "Михайлов",
		Name:       "Михаил",
		Patronymic: "Михайлович",
		Address:    "г. Самара, ул. Фрунзе, д. 9, кв. 7",
	},
	"8901_234567": {
		Surname:    "Федоров",
		Name:       "Федор",
		Patronymic: "Федорович",
		Address:    "г. Уфа, ул. Салавата, д. 11, кв. 8",
	},
	"9012_345678": {
		Surname:    "Алексеев",
		Name:       "Алексей",
		Patronymic: "Алексеевич",
		Address:    "г. Челябинск, ул. Комсомольская, д. 6, кв. 9",
	},
	"0123_456789": {
		Surname:    "Николаев",
		Name:       "Николай",
		Patronymic: "Николаевич",
		Address:    "г. Волгоград, ул. Володарского, д. 3, кв. 10",
	},
}

func getInfo(w http.ResponseWriter, r *http.Request) {
	passportSerie := r.URL.Query().Get("passportSerie")
	passportNumber := r.URL.Query().Get("passportNumber")

	if passportSerie == "" || passportNumber == "" {
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	key := passportSerie + "_" + passportNumber
	person, exists := peopleData[key]

	if !exists {
		http.Error(w, "Not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(person)
}

func main() {
	http.HandleFunc("/info", getInfo)
	fmt.Println("Server is running on port 8081")
	http.ListenAndServe(":8081", nil)
}
